// ══════════════════════════════════════════════════════════════════════════
// Scanner Tate — background
// Recibe los códigos desde la página Scanner.html y los escribe en la
// pestaña activa de Chrome, donde esté el cursor (Sheets, Gestor, Consultas…).
//
// Usa la API "debugger" de Chrome porque es la única forma de escribir como
// si fuera el teclado de verdad, y así funciona también en Google Sheets.
// Mientras la usa, Chrome muestra un aviso arriba: es normal.
// ══════════════════════════════════════════════════════════════════════════

const SOLTAR_DESPUES_MS = 2 * 60 * 1000; // suelta la pestaña tras 2 min sin escaneos
let pestanaControlada = null;
let timerSoltar = null;
let cola = Promise.resolve(); // para escribir los códigos en orden, de a uno

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (msg && msg.tipo === 'escribir') {
    cola = cola.then(() => escribir(msg.texto, msg.enter, sender.tab && sender.tab.id))
               .then(responder)
               .catch(err => responder({ ok: false, error: String(err && err.message || err) }));
    return true; // respuesta asíncrona
  }
  if (msg && msg.tipo === 'estado') {
    chrome.storage.session.get(['ultimo', 'destino']).then(d => responder({ ...d, controlada: pestanaControlada }));
    return true;
  }
  if (msg && msg.tipo === 'soltar') {
    soltar().then(() => responder({ ok: true }));
    return true;
  }
});

async function escribir(texto, enter, pestanaScanner) {
  if (!texto) return { ok: false, error: 'Código vacío' };

  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) return { ok: false, error: 'No hay ninguna pestaña activa' };
  if (tab.id === pestanaScanner) {
    return { ok: false, error: 'Estás en la pestaña del Scanner. Pasá a la pestaña donde querés escribir.' };
  }
  if (/^(chrome|edge|about|chrome-extension|devtools):/i.test(tab.url || '') || /chromewebstore\.google\.com/i.test(tab.url || '')) {
    return { ok: false, error: 'Chrome no deja escribir en esta página' };
  }

  try {
    await tomarPestana(tab.id);
    const destino = { tabId: tab.id };
    await chrome.debugger.sendCommand(destino, 'Input.insertText', { text: texto });
    if (enter) {
      await esperar(60);
      const tecla = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 };
      await chrome.debugger.sendCommand(destino, 'Input.dispatchKeyEvent', { type: 'keyDown', text: '\r', unmodifiedText: '\r', ...tecla });
      await chrome.debugger.sendCommand(destino, 'Input.dispatchKeyEvent', { type: 'keyUp', ...tecla });
    }
    await esperar(40);
    programarSoltar();
    const titulo = (tab.title || tab.url || '').slice(0, 80);
    chrome.storage.session.set({ ultimo: { texto, hora: Date.now(), titulo }, destino: titulo });
    return { ok: true, destino: titulo };
  } catch (err) {
    pestanaControlada = null;
    return { ok: false, error: traducirError(err) };
  }
}

async function tomarPestana(tabId) {
  if (pestanaControlada === tabId) return;
  if (pestanaControlada !== null) await soltar();
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
  } catch (err) {
    // Si ya estaba tomada por esta extensión (por ejemplo tras reiniciarse), seguimos igual
    if (!/already attached/i.test(String(err && err.message))) throw err;
  }
  pestanaControlada = tabId;
}

async function soltar() {
  clearTimeout(timerSoltar);
  if (pestanaControlada === null) return;
  const tabId = pestanaControlada;
  pestanaControlada = null;
  try { await chrome.debugger.detach({ tabId }); } catch (e) {}
}

function programarSoltar() {
  clearTimeout(timerSoltar);
  timerSoltar = setTimeout(soltar, SOLTAR_DESPUES_MS);
}

// Si el usuario toca "Cancelar" en el aviso de Chrome, o cierra la pestaña
chrome.debugger.onDetach.addListener((origen) => {
  if (origen.tabId === pestanaControlada) pestanaControlada = null;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === pestanaControlada) pestanaControlada = null;
});

function traducirError(err) {
  const m = String(err && err.message || err);
  if (/Cannot access|Cannot attach/i.test(m)) return 'Chrome no deja escribir en esta página';
  if (/No tab with given id/i.test(m)) return 'La pestaña se cerró';
  if (/Another debugger/i.test(m)) return 'Cerrá las herramientas de desarrollador (F12) de esa pestaña';
  return m;
}

function esperar(ms) { return new Promise(r => setTimeout(r, ms)); }
