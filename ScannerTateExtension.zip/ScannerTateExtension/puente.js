// ══════════════════════════════════════════════════════════════════════════
// Scanner Tate — puente entre la página Scanner.html y la extensión
// La página manda mensajes con window.postMessage; este script los pasa
// al background (que es el que escribe en la pestaña activa) y devuelve
// la respuesta a la página.
// ══════════════════════════════════════════════════════════════════════════

const VERSION = chrome.runtime.getManifest().version;

function aPagina(datos) {
  window.postMessage({ origen: 'scanner-tate-extension', version: VERSION, ...datos }, '*');
}

window.addEventListener('message', (e) => {
  if (e.source !== window) return;
  const m = e.data;
  if (!m || m.origen !== 'scanner-tate-pagina') return;

  // La página pregunta si la extensión está instalada
  if (m.tipo === 'ping') {
    aPagina({ tipo: 'pong' });
    return;
  }

  // La página pide escribir un código en la pestaña activa
  if (m.tipo === 'escribir') {
    try {
      chrome.runtime.sendMessage(
        { tipo: 'escribir', texto: String(m.texto || ''), enter: !!m.enter },
        (resp) => {
          if (chrome.runtime.lastError) {
            aPagina({ tipo: 'resultado', id: m.id, ok: false, error: 'La extensión no respondió. Recargá esta página.' });
          } else {
            aPagina({ tipo: 'resultado', id: m.id, ...(resp || { ok: false, error: 'Sin respuesta' }) });
          }
        }
      );
    } catch (err) {
      // Pasa si se actualizó o recargó la extensión con la página abierta
      aPagina({ tipo: 'resultado', id: m.id, ok: false, error: 'Se actualizó la extensión. Recargá esta página.' });
    }
  }
});

// Aviso apenas carga la página, por si ya está esperando
aPagina({ tipo: 'pong' });
document.addEventListener('DOMContentLoaded', () => aPagina({ tipo: 'pong' }));
