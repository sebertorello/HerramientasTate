// Popup de la extensión: muestra el estado y permite soltar la pestaña
document.getElementById('version').textContent = 'Versión ' + chrome.runtime.getManifest().version;

function actualizar() {
  chrome.runtime.sendMessage({ tipo: 'estado' }, (d) => {
    if (chrome.runtime.lastError || !d) return;
    if (d.ultimo) {
      const hora = new Date(d.ultimo.hora).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
      document.getElementById('ultimo').innerHTML = '';
      const c = document.createElement('code'); c.textContent = d.ultimo.texto;
      document.getElementById('ultimo').append(c, ' · ' + hora);
    }
    const controlando = d.controlada !== null && d.controlada !== undefined;
    document.getElementById('cajaDestino').style.display = controlando ? 'block' : 'none';
    document.getElementById('soltar').style.display = controlando ? 'block' : 'none';
    document.getElementById('destino').textContent = d.destino || '';
  });
}

document.getElementById('soltar').addEventListener('click', () => {
  chrome.runtime.sendMessage({ tipo: 'soltar' }, actualizar);
});

actualizar();
